<!doctype html>
<html>
<head>
    <title>Laravel Notify</title>
    @notifyCss
</head>
<body>

<x:notify-messages />
@notifyJs
</body>
</html>
