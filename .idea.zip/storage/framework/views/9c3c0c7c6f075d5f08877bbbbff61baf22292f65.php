<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="/admin/dashboard" class="waves-effect">
                        <i class="ri-dashboard-line"></i><span
                            class="badge badge-pill badge-success float-right"></span>
                        <span>Dashboard</span>
                    </a>
                </li>


                <li>
                    <a href="/admin/sliders" class=" waves-effect">
                        <i class="mdi-signature-image"></i>
                        <span>Sliders</span>
                    </a>
                </li>
                <li>
                    <a href="/admin/videos" class=" waves-effect">
                        <i class="ri-book-2-fill"></i>
                        <span>Video</span>
                    </a>
                </li>


                <li>
                    <a href="/admin/news" class=" waves-effect">
                        <i class="ri-newspaper-fill"></i>
                        <span>Articles</span>
                    </a>
                </li>

                <li>
                    <a href="/admin/photos" class=" waves-effect">
                        <i class="ri-newspaper-fill"></i>
                        <span>Logos</span>
                    </a>
                </li>



                


                

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH E:\PROTHOM ALO\seylon_fifa\resources\views/includes/admin/sidebar.blade.php ENDPATH**/ ?>