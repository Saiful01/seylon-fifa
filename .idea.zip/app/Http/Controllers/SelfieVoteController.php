<?php

namespace App\Http\Controllers;

use App\Models\SelfieVote;
use Illuminate\Http\Request;

class SelfieVoteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SelfieVote  $selfieVote
     * @return \Illuminate\Http\Response
     */
    public function show(SelfieVote $selfieVote)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SelfieVote  $selfieVote
     * @return \Illuminate\Http\Response
     */
    public function edit(SelfieVote $selfieVote)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SelfieVote  $selfieVote
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SelfieVote $selfieVote)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SelfieVote  $selfieVote
     * @return \Illuminate\Http\Response
     */
    public function destroy(SelfieVote $selfieVote)
    {
        //
    }
}
